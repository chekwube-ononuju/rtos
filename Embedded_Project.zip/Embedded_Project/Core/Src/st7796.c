#include "st7796.h"
#include <string.h>

// ---- GPIO helpers ----
static inline void CS_LOW(void){  HAL_GPIO_WritePin(ST7796_CS_GPIO,  ST7796_CS_PIN,  GPIO_PIN_RESET); }
static inline void CS_HIGH(void){ HAL_GPIO_WritePin(ST7796_CS_GPIO,  ST7796_CS_PIN,  GPIO_PIN_SET); }
static inline void DC_LOW(void){  HAL_GPIO_WritePin(ST7796_DC_GPIO,  ST7796_DC_PIN,  GPIO_PIN_RESET); }
static inline void DC_HIGH(void){ HAL_GPIO_WritePin(ST7796_DC_GPIO,  ST7796_DC_PIN,  GPIO_PIN_SET); }
static inline void RST_LOW(void){ HAL_GPIO_WritePin(ST7796_RST_GPIO, ST7796_RST_PIN, GPIO_PIN_RESET); }
static inline void RST_HIGH(void){HAL_GPIO_WritePin(ST7796_RST_GPIO, ST7796_RST_PIN, GPIO_PIN_SET); }

// ---- SPI write helpers ----
static void st_cmd(uint8_t cmd){
  CS_LOW(); DC_LOW();
  HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
  CS_HIGH();
}
static void st_data8(uint8_t d){
  CS_LOW(); DC_HIGH();
  HAL_SPI_Transmit(&hspi1, &d, 1, HAL_MAX_DELAY);
  CS_HIGH();
}
static void st_data16(uint16_t d){
  uint8_t b[2] = { (uint8_t)(d >> 8), (uint8_t)d };
  CS_LOW(); DC_HIGH();
  HAL_SPI_Transmit(&hspi1, b, 2, HAL_MAX_DELAY);
  CS_HIGH();
}
static void st_data(const uint8_t* buf, size_t len){
  CS_LOW(); DC_HIGH();
  HAL_SPI_Transmit(&hspi1, (uint8_t*)buf, len, HAL_MAX_DELAY);
  CS_HIGH();
}

// ---- Address window ----
static void set_window(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1){
  st_cmd(0x2A); // CASET
  uint8_t ca[4] = { x0>>8, x0&0xFF, x1>>8, x1&0xFF };
  st_data(ca, 4);

  st_cmd(0x2B); // RASET
  uint8_t ra[4] = { y0>>8, y0&0xFF, y1>>8, y1&0xFF };
  st_data(ra, 4);

  st_cmd(0x2C); // RAMWR
}

// ---- Minimal ST7796S init ----
void ST7796_Init(void){
  // Hardware reset
  RST_LOW();  HAL_Delay(20);
  RST_HIGH(); HAL_Delay(150);

  st_cmd(0x01); // SWRESET
  HAL_Delay(120);

  st_cmd(0x11); // SLPOUT
  HAL_Delay(120);

  st_cmd(0x3A); st_data8(0x55); // COLMOD: 16-bit/pixel
  st_cmd(0x36); st_data8(0x48); // MADCTL: rotation/BGR (adjust if orientation is off)

  // Power/porch/gamma: safe defaults known to work
  st_cmd(0xB2); uint8_t b2[]={0x0C,0x0C,0x00,0x33,0x33}; st_data(b2,sizeof b2);
  st_cmd(0xB7); st_data8(0x35);
  st_cmd(0xBB); st_data8(0x2B);
  st_cmd(0xC0); st_data8(0x2C);
  st_cmd(0xC2); uint8_t c2[]={0x01,0xFF}; st_data(c2,sizeof c2);
  st_cmd(0xC3); st_data8(0x11);
  st_cmd(0xC4); st_data8(0x20);
  st_cmd(0xC6); st_data8(0x0F);
  st_cmd(0xD0); uint8_t d0[]={0xA4,0xA1}; st_data(d0,sizeof d0);

  st_cmd(0xE0); uint8_t pg[]={0xD0,0x08,0x11,0x08,0x0C,0x15,0x39,0x33,0x50,0x36,0x13,0x14,0x29,0x2D}; st_data(pg,sizeof pg);
  st_cmd(0xE1); uint8_t ng[]={0xD0,0x08,0x10,0x08,0x06,0x06,0x39,0x44,0x51,0x0B,0x16,0x14,0x2F,0x31}; st_data(ng,sizeof ng);

  st_cmd(0x29); // DISPON
  HAL_Delay(50);
}

void ST7796_DrawPixel(uint16_t x, uint16_t y, uint16_t color){
  if(x>=ST7796_TFTWIDTH || y>=ST7796_TFTHEIGHT) return;
  set_window(x,y,x,y);
  st_data16(color);
}

void ST7796_FillScreen(uint16_t color){
  set_window(0,0,ST7796_TFTWIDTH-1,ST7796_TFTHEIGHT-1);
  CS_LOW(); DC_HIGH();
  uint8_t hi = (uint8_t)(color >> 8), lo = (uint8_t)color;
  // Simple streaming loop
  for(uint32_t i=0;i<(uint32_t)ST7796_TFTWIDTH*ST7796_TFTHEIGHT;i++){
    uint8_t px[2]={hi,lo};
    HAL_SPI_Transmit(&hspi1, px, 2, HAL_MAX_DELAY);
  }
  CS_HIGH();
}

void ST7796_DrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color){
  for(uint16_t i=0;i<w;i++){ ST7796_DrawPixel(x+i, y, color); }
  for(uint16_t i=0;i<w;i++){ ST7796_DrawPixel(x+i, y+h-1, color); }
  for(uint16_t j=0;j<h;j++){ ST7796_DrawPixel(x, y+j, color); }
  for(uint16_t j=0;j<h;j++){ ST7796_DrawPixel(x+w-1, y+j, color); }
}

// ---- Tiny 5x7 font (only needed glyphs) ----
static const uint8_t glyph_5x7[][5] = {
  /* space */ {0x00,0x00,0x00,0x00,0x00},
  /* 1 */     {0x04,0x0C,0x04,0x04,0x0E},
  /* 2 */     {0x0E,0x01,0x0E,0x08,0x0F},
  /* 3 */     {0x0E,0x01,0x06,0x01,0x0E},
  /* C */     {0x0E,0x08,0x08,0x08,0x0E},
  /* E */     {0x0F,0x08,0x0E,0x08,0x0F},
  /* N */     {0x09,0x0D,0x0B,0x09,0x09},
  /* O */     {0x0E,0x09,0x09,0x09,0x0E},
  /* R */     {0x0F,0x09,0x0F,0x0A,0x09},
  /* T */     {0x1F,0x04,0x04,0x04,0x04},
};
static int gi(char c){
  switch(c){
    case ' ': return 0; case '1': return 1; case '2': return 2; case '3': return 3;
    case 'C': return 4; case 'E': return 5; case 'N': return 6; case 'O': return 7;
    case 'R': return 8; case 'T': return 9; default: return -1;
  }
}
void ST7796_DrawChar5x7(uint16_t x,uint16_t y,char c,uint16_t fg,uint16_t bg,uint8_t s){
  int idx = gi(c); if(idx<0) return;
  for(int col=0; col<5; col++){
    uint8_t bits = glyph_5x7[idx][col];
    for(int row=0; row<7; row++){
      uint16_t color = (bits & (1<<row)) ? fg : bg;
      for(uint8_t dx=0; dx<s; dx++){
        for(uint8_t dy=0; dy<s; dy++){
          ST7796_DrawPixel(x + col*s + dx, y + row*s + dy, color);
        }
      }
    }
  }
  // 1 column spacing
  for(int row=0; row<7*s; row++){
    for(uint8_t dx=0; dx<s; dx++){
      ST7796_DrawPixel(x + 5*s + dx, y + row, bg);
    }
  }
}
void ST7796_DrawString(uint16_t x,uint16_t y,const char* s,uint16_t fg,uint16_t bg,uint8_t scale){
  uint16_t cx=x;
  while(*s){
    ST7796_DrawChar5x7(cx,y,*s,fg,bg,scale);
    cx += 6*scale; // 5 cols + 1 space
    s++;
  }
}
