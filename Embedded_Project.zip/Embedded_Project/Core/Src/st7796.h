#ifndef ST7796_H
#define ST7796_H

#include "main.h"

// ---------- Pin mapping (matches your PB5/PB4/PB3) ----------
#define ST7796_CS_GPIO      GPIOB
#define ST7796_CS_PIN       GPIO_PIN_5
#define ST7796_DC_GPIO      GPIOB
#define ST7796_DC_PIN       GPIO_PIN_4
#define ST7796_RST_GPIO     GPIOB
#define ST7796_RST_PIN      GPIO_PIN_3

// ---------- Display resolution ----------
#define ST7796_TFTWIDTH   320
#define ST7796_TFTHEIGHT  480

// ---------- Colors (RGB565) ----------
#define COLOR_BLACK   0x0000
#define COLOR_WHITE   0xFFFF

extern SPI_HandleTypeDef hspi1;

void ST7796_Init(void);
void ST7796_FillScreen(uint16_t color);
void ST7796_DrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void ST7796_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void ST7796_DrawChar5x7(uint16_t x, uint16_t y, char c, uint16_t fg, uint16_t bg, uint8_t scale);
void ST7796_DrawString(uint16_t x, uint16_t y, const char* s, uint16_t fg, uint16_t bg, uint8_t scale);

#endif
