/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <math.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

	typedef struct task
	{
		int state;
		unsigned long period;
		unsigned long elapsedTime;
		int (*Function) (int);
	} task;

	/* Base scheduler
	 * task periods  in milliseconds.
	 */
	const unsigned int  numTasks    = 3;
	const unsigned long period      = 1;
	const unsigned long ina1Period  = 1;
	const unsigned long ina2Period  = 1;
	const unsigned long relayPeriod = 100;

	task tasks[3];

	/* storing averaged INA219 data */
	typedef struct {
	    float bus_V;
	    float shunt_V;
	    float current_A;
	    float power_W;
	} INA219_Data;

		/* averaging `0 samples */
	#define INA_AVG_SAMPLES  10   /* 10 samples @ 1 kHz = 10 ms window */


	static float ina1_sum_bus   = 0.0f;
	static float ina1_sum_shunt = 0.0f;
	static float ina1_sum_curr  = 0.0f;
	static float ina1_sum_power = 0.0f;

	static float ina2_sum_bus   = 0.0f;
	static float ina2_sum_shunt = 0.0f;
	static float ina2_sum_curr  = 0.0f;
	static float ina2_sum_power = 0.0f;

	static char  ina_sample_count = 0;


	/* Latest computed averages */
	static INA219_Data ina1_avg;
	static INA219_Data ina2_avg;

	/* Flag to tell UART task that new averages are ready */
	static volatile uint8_t ina_avg_ready = 0;


	enum INA_states { INA_on, INA_off };
	int INA_read  (int state);   // Task 0
	int INA2_read (int state);   // Task 1
	int RelayTask (int state);   // Task 2

	/* RELAY STATE MACHINE */

	enum RelayState {
	    RELAY_ON_MONITOR = 0,  // dock powered, watching current
	    RELAY_OFF_SLEEP,       // dock off, waiting for timed or manual wake
	    RELAY_PROBE            // dock briefly on to check current
	};

	static enum RelayState relayState = RELAY_ON_MONITOR;

	/* Timing constants*/
	const unsigned long FULL_STABLE_MS = 10UL * 1000UL;
	const unsigned long SLEEP_MS       = 30UL * 60UL * 1000UL;
	const unsigned long PROBE_MS       = 10000UL;

	/* Current thresholds (Amps)*/
	const float FULL_CURRENT_THRESH = 0.1f;   // < 10 mA → consider "full/idle"
	const float CHARGING_THRESH     = 0.20f;   // > 20 mA → clearly charging

	/* timers */
	static unsigned long fullStartMs    = 0;
	static unsigned long sleepStartMs   = 0;
	static unsigned long probeStartMs   = 0;

	/* manual wake flag set by blue user button (B1) interrupt */
	static volatile uint8_t manualWakeRequest = 0;

	//enum TL_states {TL0, TL1, TL2};
	//int ThreeLED (int state);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


#define RELAY_GPIO_PORT  GPIOB
#define RELAY_PIN        GPIO_PIN_3

#define RELAY_ON()   HAL_GPIO_WritePin(RELAY_GPIO_PORT, RELAY_PIN, GPIO_PIN_SET)
#define RELAY_OFF()  HAL_GPIO_WritePin(RELAY_GPIO_PORT, RELAY_PIN, GPIO_PIN_RESET)




void TimerISR(void)
{
    unsigned char i;
    for (i = 0; i < numTasks; i++)
    {
        if (tasks[i].elapsedTime >= tasks[i].period)
        {
            tasks[i].state = tasks[i].Function(tasks[i].state);
            tasks[i].elapsedTime = 0;
        }
        tasks[i].elapsedTime += period;
    }
}


int __io_putchar(int ch) {
 HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, HAL_MAX_DELAY); //change this uart for esp or computer readings
 return ch;
}
/* INA219 DEFINES */


/* Two INA219 addresses */
#define INA1_ADDR_7B   0x40   // A1/A0 = default
#define INA2_ADDR_7B   0x45   // your second device

#define INA219_REG_CONFIG     0x00
#define INA219_REG_SHUNT      0x01
#define INA219_REG_BUS        0x02
#define INA219_REG_POWER      0x03
#define INA219_REG_CURRENT    0x04
#define INA219_REG_CAL        0x05


/* Current_LSB */
static const float INA219_R_SHUNT_OHMS  = 0.10f;     /* CHANGE if different */
static const float INA219_CURRENT_LSB_A = 0.0001f;   /* 0.1 mA/bit */
static const float INA219_POWER_LSB_W   = 20.0f * INA219_CURRENT_LSB_A;

extern I2C_HandleTypeDef hi2c1;

static HAL_StatusTypeDef INA219_WriteReg16(char addr7, char reg, short value)
{
    char buf[3];
    buf[0] = reg;
    buf[1] = (char)(value >> 8);
    buf[2] = (char)(value & 0xFF);

    return HAL_I2C_Master_Transmit(&hi2c1,
                                   (short)(addr7 << 1),
                                   (unsigned char*)buf,
                                   3,
                                   HAL_MAX_DELAY);
}

static HAL_StatusTypeDef INA219_ReadReg16(char addr7, char reg, short *value)
{
    char rx[2];

    if (HAL_I2C_Master_Transmit(&hi2c1,
                                (short)(addr7 << 1),
                                (unsigned char*)&reg,
                                1,
                                HAL_MAX_DELAY) != HAL_OK)
        return HAL_ERROR;

    if (HAL_I2C_Master_Receive(&hi2c1,
                               (short)(addr7 << 1),
                               (unsigned char*)rx,
                               2,
                               HAL_MAX_DELAY) != HAL_OK)
        return HAL_ERROR;

    *value = (short)(((short)rx[0] << 8) | (short)rx[1]);
    return HAL_OK;
}
static HAL_StatusTypeDef INA219_SetConfig(char addr7)
{
    /* BRNG=1 (32V), PG=11 (+-320mV), BADC=1000, SADC=1000, MODE=111 */
    unsigned short config = 0x1F9F;
    return INA219_WriteReg16(addr7, INA219_REG_CONFIG, (short)config);
}

static HAL_StatusTypeDef INA219_SetCalibration(char addr7,
                                               float r_shunt,
                                               float current_lsb)
{
    float cal_f = 0.04096f / (current_lsb * r_shunt);
    unsigned short cal = (unsigned short)lroundf(cal_f);
    if (cal == 0) cal = 1;
    return INA219_WriteReg16(addr7, INA219_REG_CAL, (short)cal);
}

static HAL_StatusTypeDef INA219_Init(char addr7)
{
    if (INA219_SetConfig(addr7) != HAL_OK) {
        printf("INA219(0x%02X) config write failed\r\n", (unsigned char)addr7);
        return HAL_ERROR;
    }
    if (INA219_SetCalibration(addr7,
                              INA219_R_SHUNT_OHMS,
                              INA219_CURRENT_LSB_A) != HAL_OK) {
        printf("INA219(0x%02X) calibration write failed\r\n", (unsigned char)addr7);
        return HAL_ERROR;
    }
    HAL_Delay(2);
    return HAL_OK;
}

static HAL_StatusTypeDef INA219_ReadData(char addr7, INA219_Data *out)
{
    short raw_shunt;
    short raw_bus;
    short raw_current;
    short raw_power;

    if (INA219_ReadReg16(addr7, INA219_REG_SHUNT, &raw_shunt) != HAL_OK ||
        INA219_ReadReg16(addr7, INA219_REG_BUS,   &raw_bus)   != HAL_OK)
    {
        return HAL_ERROR;
    }

    short shunt_signed = raw_shunt;               /* 10 µV / LSB */
    float shunt_V = (float)shunt_signed * 10e-6f;

    unsigned short bus_raw_13b = (unsigned short)((raw_bus >> 3) & 0x1FFF);
    float bus_V = (float)bus_raw_13b * 0.004f;    /* 4 mV / LSB */

    if (INA219_ReadReg16(addr7, INA219_REG_CURRENT, &raw_current) != HAL_OK ||
        INA219_ReadReg16(addr7, INA219_REG_POWER,   &raw_power)   != HAL_OK)
    {
        return HAL_ERROR;
    }

    short current_signed = raw_current;
    float current_A = (float)current_signed * INA219_CURRENT_LSB_A;
    float power_W   = (float)raw_power * INA219_POWER_LSB_W;

    out->bus_V     = bus_V;
    out->shunt_V   = shunt_V;
    out->current_A = current_A;
    out->power_W   = power_W;

    return HAL_OK;
}




int INA_read (int state)
{
    switch (state)
    {
        case INA_on:
        {
            INA219_Data d1;
            INA219_Data d2;

            /* Read both sensors once per task fire */
            if (INA219_ReadData((char)INA1_ADDR_7B, &d1) == HAL_OK &&
                INA219_ReadData((char)INA2_ADDR_7B, &d2) == HAL_OK)
            {
                /* accumulate for averaging */
                ina1_sum_bus   += d1.bus_V;
                ina1_sum_shunt += d1.shunt_V;
                ina1_sum_curr  += d1.current_A;
                ina1_sum_power += d1.power_W;

                ina2_sum_bus   += d2.bus_V;
                ina2_sum_shunt += d2.shunt_V;
                ina2_sum_curr  += d2.current_A;
                ina2_sum_power += d2.power_W;

                ina_sample_count++;

                if (ina_sample_count >= INA_AVG_SAMPLES)
                {
                    /* compute averages */
                    float n = (float)ina_sample_count;

                    ina1_avg.bus_V     = ina1_sum_bus   / n;
                    ina1_avg.shunt_V   = ina1_sum_shunt / n;
                    ina1_avg.current_A = ina1_sum_curr  / n;
                    ina1_avg.power_W   = ina1_sum_power / n;

                    ina2_avg.bus_V     = ina2_sum_bus   / n;
                    ina2_avg.shunt_V   = ina2_sum_shunt / n;
                    ina2_avg.current_A = ina2_sum_curr  / n;
                    ina2_avg.power_W   = ina2_sum_power / n;

                    /* reset accumulators for next window */
                    ina1_sum_bus   = 0.0f;
                    ina1_sum_shunt = 0.0f;
                    ina1_sum_curr  = 0.0f;
                    ina1_sum_power = 0.0f;

                    ina2_sum_bus   = 0.0f;
                    ina2_sum_shunt = 0.0f;
                    ina2_sum_curr  = 0.0f;
                    ina2_sum_power = 0.0f;

                    ina_sample_count = 0;

                    /* signal Task B that new data are ready */
                    ina_avg_ready = 1;
                }
            }
            else
            {
                printf("INA_read: read error\r\n");
            }

            state = INA_on;
            break;
        }

        default:
            state = INA_on;
            break;
    }

    return state;
}

int INA2_read (int state)   /* Task B: transmit usage data */
{
    switch (state)
    {
        case INA_on:
            if (ina_avg_ready)
            {
                ina_avg_ready = 0;   /* clear flag first */

                printf("AVG INA1: Bus=%.3f V, Shunt=%.6f V, Current=%.3f A, Power=%.3f W\r\n",
                       ina1_avg.bus_V, ina1_avg.shunt_V,
                       ina1_avg.current_A, ina1_avg.power_W);

                printf("AVG INA2: Bus=%.3f V, Shunt=%.6f V, Current=%.3f A, Power=%.3f W\r\n",
                       ina2_avg.bus_V, ina2_avg.shunt_V,
                       ina2_avg.current_A, ina2_avg.power_W);
            }

            state = INA_on;
            break;

        default:
            state = INA_on;
            break;
    }
    return state;
}


void I2C_Scan(I2C_HandleTypeDef *hi2c)
{
    printf("----- I2C SCAN START -----\r\n");

    HAL_StatusTypeDef result;
    uint8_t i2c_address;

    for (i2c_address = 1; i2c_address < 128; i2c_address++)
    {
        /*
          HAL wants 8-bit address, so shift left.
          The address you print is the real 7-bit one.
        */
        result = HAL_I2C_IsDeviceReady(hi2c, (uint16_t)(i2c_address << 1), 3, 10);

        if (result == HAL_OK)
        {
            printf("I2C device found at 0x%02X\r\n", i2c_address);
        }
    }

    printf("----- I2C SCAN COMPLETE -----\r\n");
}


/*  END INA219 SECTION */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE BEGIN 2 */
  HAL_StatusTypeDef ret;

  printf("DEBUG: after INA219_Init\r\n");
  //I2C_Scan(&hi2c1);
  printf("DEBUG: starting main init\r\n");

  HAL_StatusTypeDef ret1 = HAL_I2C_IsDeviceReady(&hi2c1,
                                                 (unsigned short)(INA1_ADDR_7B << 1),
                                                 3, 100);
  HAL_StatusTypeDef ret2 = HAL_I2C_IsDeviceReady(&hi2c1,
                                                 (unsigned short)(INA2_ADDR_7B << 1),
                                                 3, 100);

  printf("INA1 (0x%02X) %s\r\n", (unsigned char)INA1_ADDR_7B,
         (ret1 == HAL_OK) ? "READY" : "NOT READY");
  printf("INA2 (0x%02X) %s\r\n", (unsigned char)INA2_ADDR_7B,
         (ret2 == HAL_OK) ? "READY" : "NOT READY");

  /* Init both sensors */
  if (INA219_Init((char)INA1_ADDR_7B) == HAL_OK)
      printf("INA1 (0x%02X) initialized\r\n", (unsigned char)INA1_ADDR_7B);
  else
      printf("INA1 (0x%02X) init FAILED\r\n", (unsigned char)INA1_ADDR_7B);

  if (INA219_Init((char)INA2_ADDR_7B) == HAL_OK)
      printf("INA2 (0x%02X) initialized\r\n", (unsigned char)INA2_ADDR_7B);
  else
      printf("INA2 (0x%02X) init FAILED\r\n", (unsigned char)INA2_ADDR_7B);


  RELAY_ON();
  relayState   = RELAY_ON_MONITOR;
  fullStartMs  = 0;
  sleepStartMs = HAL_GetTick();


  tasks[0].state       = INA_on;          // start state
  tasks[0].period      = ina1Period;
  tasks[0].elapsedTime = tasks[0].period; // run on first scheduler call
  tasks[0].Function    = &INA_read;

  tasks[1].state       = INA_on;
  tasks[1].period      = ina2Period;
  tasks[1].elapsedTime = tasks[1].period; // fire on first TimerISR
  tasks[1].Function    = &INA2_read;

  tasks[2].state       = 0;
  tasks[2].period      = relayPeriod;
  tasks[2].elapsedTime = tasks[2].period;
  tasks[2].Function    = &RelayTask;
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  unsigned long lastTick = HAL_GetTick();

  while (1)
  {
      unsigned long now = HAL_GetTick();

      if ((now - lastTick) >= period)
      {
          TimerISR();
          lastTick = now;
      }


  }
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
  }



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */
  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */
  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10D19CE4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */
  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */
  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */
  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */
  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */
  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */
  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /* === USER BUTTON B1: PC13, EXTI on FALLING edge === */
  GPIO_InitStruct.Pin = B1_Pin;           // PC13
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);


  /* === RELAY + OTHER OUTPUTS: PB3, PB4, PB5 === */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* === Enable EXTI interrupt line for PC13 (EXTI15_10) === */
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == B1_Pin)
    {
        // manual wake: force relay ON if it is off
        manualWakeRequest = 1;
        //printf("B1 pressed!\r\n");
    }
}

int RelayTask(int dummyState)
{
    unsigned long now = HAL_GetTick();

    /* Copy and clear manual flag atomically */
    uint8_t manual = manualWakeRequest;
    if (manual)
        manualWakeRequest = 0;

    switch (relayState)
    {
        case RELAY_ON_MONITOR:
        {

            if (manual)
            {
                fullStartMs = 0;
            }

            float iA = ina1_avg.current_A;

            if (iA < FULL_CURRENT_THRESH)
            {
                if (fullStartMs == 0)
                    fullStartMs = now;

                if ((now - fullStartMs) >= FULL_STABLE_MS)
                {

                    RELAY_OFF();
                    relayState   = RELAY_OFF_SLEEP;
                    sleepStartMs = now;
                    fullStartMs  = 0;

                }
            }
            else
            {

                fullStartMs = 0;
            }
            break;
        }

        case RELAY_OFF_SLEEP:
        {
            // Blue button: immediate wake / enable charging
            if (manual)
            {
                RELAY_ON();
                relayState  = RELAY_ON_MONITOR;
                fullStartMs = 0;
                // printf("Relay: MANUAL WAKE\r\n");
                break;
            }

            // Auto timed wake to probe every SLEEP_MS
            if ((now - sleepStartMs) >= SLEEP_MS)
            {
                RELAY_ON();
                relayState    = RELAY_PROBE;
                probeStartMs  = now;
                // printf("Relay: PROBE START\r\n");
            }
            break;
        }

        case RELAY_PROBE:
        {
            // During PROBE, INA task continues to run and update ina1_avg.
            if ((now - probeStartMs) >= PROBE_MS)
            {
                float iA = ina1_avg.current_A;

                if (iA > CHARGING_THRESH)
                {
                    // it is drawing real current – leave relay ON and go monitor
                    relayState  = RELAY_ON_MONITOR;
                    fullStartMs = 0;
                    // printf("Relay: PROBE found charging, stay ON\r\n");
                }
                else
                {
                    //  no charging → go back to sleep, relay OFF
                    RELAY_OFF();
                    relayState   = RELAY_OFF_SLEEP;
                    sleepStartMs = now;
                    // printf("Relay: PROBE idle, back to SLEEP\r\n");
                }
            }
            break;
        }

        default:
            relayState = RELAY_ON_MONITOR;
            break;
    }

    return dummyState;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
 /* User can add his own implementation to report the HAL error return state */
 __disable_irq();
 while (1)
 {
 }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
 /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
